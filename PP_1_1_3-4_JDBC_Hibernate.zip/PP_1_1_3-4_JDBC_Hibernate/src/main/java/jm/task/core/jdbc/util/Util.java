package jm.task.core.jdbc.util;

import com.mysql.cj.jdbc.Driver;
import jm.task.core.jdbc.model.User;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class Util {
    // реализуйте настройку соеденения с БД

    private static final String URL = "jdbc:mysql://localhost:3306/prep";
    private static final String USER = "root";
    private static final String PASS = "859929sql";
    private static final String DIALECT = "org.hibernate.dialect.MySQL8Dialect";
    private static final String HBM2DDL = "update";
    private static final String SHOW_SQL = "true";
    private static final String CONNECTION_POOL_TIMEOUT = "0";

    public static Connection getConnection() {

        Connection connection = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASS);
            System.out.println("Подключение успешно");
        } catch (SQLException e) {
            System.out.println("Подключение не успешно");
        }
        return connection;
    }

    public static SessionFactory getSession() {
        Properties prop = new Properties();

        prop.setProperty(Environment.DRIVER, Driver.class.getCanonicalName());
        prop.setProperty(Environment.URL, URL);
        prop.setProperty(Environment.USER, USER);
        prop.setProperty(Environment.PASS, PASS);
        prop.setProperty(Environment.DIALECT, DIALECT);
        prop.setProperty(Environment.HBM2DDL_AUTO, HBM2DDL);
        prop.setProperty(Environment.SHOW_SQL, SHOW_SQL);
        prop.setProperty(Environment.C3PO_TIMEOUT, CONNECTION_POOL_TIMEOUT);

        Configuration configuration = new Configuration();
        configuration.setProperties(prop);
        configuration.addAnnotatedClass(User.class);

        StandartServiceRegistry servReg = new StandartServiceRegisteryBuilder().applySettings(configuration.getProperties()).build();
        SessionFactory sesFact = configuration.buildSessionFactory(servReg);

        return sesFact;

    }

}
